import java.io.*;
import java.util.*;
public class Chess {
	static int count=0;
	static File f1 =null;
	
	// Below 12 methods are used to get the possible moves of the particular coin. Each method is named by coin name
	static String White_Rook(String board[][],int i,int j,int k) {
		
		String PossibleMoves="";
		int m;
		for(m=j+1;m<9;m++) {
			if(board[i][m].charAt(0)=='W') {
				break;
			}
			if(board[i][m].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[i][m]+" At Position : "+(board[0][m].trim()+board[i][0]));
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}else {
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
			}
		}
		for(m=j-1;m>0;m--) {
			if(board[i][m].charAt(0)=='W') {
				break;
			}
			if(board[i][m].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[i][m]+" At Position : "+(board[0][m].trim()+board[i][0]));
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}else {
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
			}
		}
		for(m=i+1;m<9;m++) {
			if(board[m][j].charAt(0)=='W') {
				break;
			}
			if(board[m][j].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][j]+" At Position : "+(board[0][j].trim()+board[m][0]));
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
			}
		}
		for(m=i-1;m>0;m--) {
			if(board[m][j].charAt(0)=='W') {
				break;
			}
			if(board[m][j].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][j]+" At Position : "+(board[0][j].trim()+board[m][0]));
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
			}
		}
		return PossibleMoves;
		
	}
	static String Black_Rook(String board[][],int i,int j,int k) {
		String PossibleMoves="";
		int m;
		for(m=j+1;m<9;m++) {
			if(board[i][m].charAt(0)=='B') {
				break;
			}
			if(board[i][m].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[i][m]+" At Position : "+(board[0][m].trim()+board[i][0]));
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}else {
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
			}
		}
		for(m=j-1;m>0;m--) {
			if(board[i][m].charAt(0)=='B') {
				break;
			}
			if(board[i][m].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[i][m]+" At Position : "+(board[0][m].trim()+board[i][0]));
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}else {
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
			}
		}
		for(m=i+1;m<9;m++) {
			if(board[m][j].charAt(0)=='B') {
				break;
			}
			if(board[m][j].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][j]+" At Position : "+(board[0][j].trim()+board[m][0]));
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
			}
		}
		for(m=i-1;m>0;m--) {
			if(board[m][j].charAt(0)=='B') {
				break;
			}
			if(board[m][j].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][j]+" At Position : "+(board[0][j].trim()+board[m][0]));
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
			}
		}
		return PossibleMoves;
	}
	static String Black_Knight(String board[][],int i,int j,int k) {
		String PossibleMoves="";
		int m,n,a;
		int Check[]= {i-2,j-1,i-2,j+1,i+2,j-1,i+2,j+1,i-1,j-2,i+1,j-2,i-1,j+2,i+1,j+2};
		for(a=0;a<Check.length;a+=2) {
			m=Check[a];n=Check[a+1];
			if(m>0 && m<9 && n>0 && n<9 && board[m][n].charAt(0)!='B') {
				if(board[m][n].charAt(0)=='W') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
			}
		}
		return PossibleMoves;
	}
	static String White_Knight(String board[][],int i,int j,int k) {
		String PossibleMoves="";
		int m,n,a;
		int Check[]= {i-2,j-1,i-2,j+1,i+2,j-1,i+2,j+1,i-1,j-2,i+1,j-2,i-1,j+2,i+1,j+2};
		for(a=0;a<Check.length;a+=2) {
			m=Check[a];n=Check[a+1];
			if(m>0 && m<9 && n>0 && n<9 && board[m][n].charAt(0)!='W') {
				if(board[m][n].charAt(0)=='B') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
			}
		}
		return PossibleMoves;
	}
	static String Black_Bishop(String board[][],int i,int j,int k) {
		String PossibleMoves="";
		int m,n;
			m=i-1;n=j-1;
			while(m!=0 && n!=0) {
				if(board[m][n].charAt(0)=='B') {
					break;
				}
				if(board[m][n].charAt(0)=='W') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				m--;n--;
			}
			m=i+1;n=j+1;
			while(m!=9 && n!=9) {
				if(board[m][n].charAt(0)=='B') {
					break;
				}
				if(board[m][n].charAt(0)=='W') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				m++;n++;
			}
			m=i-1;n=j+1;
			while(m>0 && m<9 && n>0 && n<9) {
				if(board[m][n].charAt(0)=='B') {
					break;
				}
				if(board[m][n].charAt(0)=='W') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				m--;n++;
			}
			m=i+1;n=j-1;
			while(m>0 && m<9 && n>0 && n<9) {
				if(board[m][n].charAt(0)=='B') {
					break;
				}
				if(board[m][n].charAt(0)=='W') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				m++;n--;
			}
			return PossibleMoves;
			
			
	}
	static String White_Bishop(String board[][],int i,int j,int k) {
		String PossibleMoves="";
		int m,n;
			m=i-1;n=j-1;
			while(m!=0 && n!=0) {
				if(board[m][n].charAt(0)=='W') {
					break;
				}
				if(board[m][n].charAt(0)=='B') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				m--;n--;
			}
			m=i+1;n=j+1;
			while(m!=9 && n!=9) {
				if(board[m][n].charAt(0)=='W') {
					break;
				}
				if(board[m][n].charAt(0)=='B') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				m++;n++;
			}
			m=i-1;n=j+1;
			while(m>0 && m<9 && n>0 && n<9) {
				if(board[m][n].charAt(0)=='W') {
					break;
				}
				if(board[m][n].charAt(0)=='B') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				m--;n++;
			}
			m=i+1;n=j-1;
			while(m>0 && m<9 && n>0 && n<9) {
				if(board[m][n].charAt(0)=='W') {
					break;
				}
				if(board[m][n].charAt(0)=='B') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				m++;n--;
			}
			return PossibleMoves;
			
			
	}
	static String Black_King(String board[][],int i,int j,int k) {
		String PossibleMoves="";
		int m,n,a;
		int Check[]= {i-1,j-1,i-1,j,i-1,j+1,i,j-1,i,j+1,i+1,j-1,i+1,j,i+1,j+1};
		for(a=0;a<Check.length;a+=2) {
			m=Check[a];n=Check[a+1];
			if(m>0 && m<9 && n>0 && n<9 && board[m][n].charAt(0)!='B') {
				if(board[m][n].charAt(0)=='W') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
			}
		}
		return PossibleMoves;
	}
	static String White_King(String board[][],int i,int j,int k) {
		String PossibleMoves="";
		int m,n,a;
		int Check[]= {i-1,j-1,i-1,j,i-1,j+1,i,j-1,i,j+1,i+1,j-1,i+1,j,i+1,j+1};
		for(a=0;a<Check.length;a+=2) {
			m=Check[a];n=Check[a+1];
			if(m>0 && m<9 && n>0 && n<9 && board[m][n].charAt(0)!='W') {
				if(board[m][n].charAt(0)=='B') {
					if(k==0) {
						System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}else {
						PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
					}
					break;
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
			}
		}
		return PossibleMoves;
	}
	static String Black_Queen(String board[][],int i,int j,int k) {
		String PossibleMoves="";
		int m,n;
		for(m=j+1;m<9;m++) {
			if(board[i][m].charAt(0)=='B') {
				break;
			}
			if(board[i][m].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[i][m]+" At Position : "+(board[0][m].trim()+board[i][0]));
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}else {
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
			}
		}
		for(m=j-1;m>0;m--) {
			if(board[i][m].charAt(0)=='B') {
				break;
			}
			if(board[i][m].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[i][m]+" At Position : "+(board[0][m].trim()+board[i][0]));
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}else {
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
			}
		}
		for(m=i+1;m<9;m++) {
			if(board[m][j].charAt(0)=='B') {
				break;
			}
			if(board[m][j].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][j]+" At Position : "+(board[0][j].trim()+board[m][0]));
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
			}
		}
		for(m=i-1;m>0;m--) {
			if(board[m][j].charAt(0)=='B') {
				break;
			}
			if(board[m][j].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][j]+" At Position : "+(board[0][j].trim()+board[m][0]));
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
			}
		}
		m=i-1;n=j-1;
		while(m!=0 && n!=0) {
			if(board[m][n].charAt(0)=='B') {
				break;
			}
			if(board[m][n].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
			}
			m--;n--;
		}
		m=i+1;n=j+1;
		while(m!=9 && n!=9) {
			if(board[m][n].charAt(0)=='B') {
				break;
			}
			if(board[m][n].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
			}
			m++;n++;
		}
		m=i-1;n=j+1;
		while(m>0 && m<9 && n>0 && n<9) {
			if(board[m][n].charAt(0)=='B') {
				break;
			}
			if(board[m][n].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
			}
			m--;n++;
		}
		m=i+1;n=j-1;
		while(m>0 && m<9 && n>0 && n<9) {
			if(board[m][n].charAt(0)=='B') {
				break;
			}
			if(board[m][n].charAt(0)=='W') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
			}
			m++;n--;
		}
		return PossibleMoves;
	}
	static String White_Queen(String board[][],int i,int j,int k) {
		String PossibleMoves="";
		int m,n;
		for(m=j+1;m<9;m++) {
			if(board[i][m].charAt(0)=='W') {
				break;
			}
			if(board[i][m].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[i][m]+" At Position : "+(board[0][m].trim()+board[i][0]));
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}else {
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
			}
		}
		for(m=j-1;m>0;m--) {
			if(board[i][m].charAt(0)=='W') {
				break;
			}
			if(board[i][m].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[i][m]+" At Position : "+(board[0][m].trim()+board[i][0]));
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}else {
					PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][m].trim()+board[i][0])+", ";
			}
		}
		for(m=i+1;m<9;m++) {
			if(board[m][j].charAt(0)=='W') {
				break;
			}
			if(board[m][j].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][j]+" At Position : "+(board[0][j].trim()+board[m][0]));
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
			}
		}
		for(m=i-1;m>0;m--) {
			if(board[m][j].charAt(0)=='W') {
				break;
			}
			if(board[m][j].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][j]+" At Position : "+(board[0][j].trim()+board[m][0]));
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][j].trim()+board[m][0])+", ";
			}
		}
		m=i-1;n=j-1;
		while(m!=0 && n!=0) {
			if(board[m][n].charAt(0)=='W') {
				break;
			}
			if(board[m][n].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
			}
			m--;n--;
		}
		m=i+1;n=j+1;
		while(m!=9 && n!=9) {
			if(board[m][n].charAt(0)=='W') {
				break;
			}
			if(board[m][n].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
			}
			m++;n++;
		}
		m=i-1;n=j+1;
		while(m>0 && m<9 && n>0 && n<9) {
			if(board[m][n].charAt(0)=='W') {
				break;
			}
			if(board[m][n].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
			}
			m--;n++;
		}
		m=i+1;n=j-1;
		while(m>0 && m<9 && n>0 && n<9) {
			if(board[m][n].charAt(0)=='W') {
				break;
			}
			if(board[m][n].charAt(0)=='B') {
				if(k==0) {
					System.out.println("You can capture  : "+board[m][n]+" At Position : "+(board[0][n].trim()+board[m][0]));
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}else {
					PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
				}
				break;
			}else {
				PossibleMoves += (board[0][n].trim()+board[m][0])+", ";
			}
			m++;n--;
		}
		return PossibleMoves;
	}
	static String Black_Pawn(String board[][],int i,int j,int k) {
		String PossibleMoves="";
		int a;
		if(k==0) {
			if(i==2) {
				for(a=i+1;a<5;a++) {
					PossibleMoves += (board[0][j].trim()+board[a][0])+", ";
				}
			}else {
				if(i<8 && board[i+1][j].charAt(0)!='W' && board[i+1][j].charAt(0)!='B') {
					PossibleMoves += (board[0][j].trim()+board[i+1][0])+", ";
				}
				if(i<8 && board[i+1][j-1].charAt(0)=='W') {
					System.out.println("You can capture  : "+board[i+1][j-1]+" At Position : "+(board[0][j-1].trim()+board[i+1][0]));
					PossibleMoves += (board[0][j-1].trim()+board[i+1][0])+", ";
				}
				
				if(i<8 && board[i+1][j+1].charAt(0)=='W') {
					System.out.println("You can capture  : "+board[i+1][j+1]+" At Position : "+(board[0][j+1].trim()+board[i+1][0]));
					PossibleMoves += (board[0][j+1].trim()+board[i+1][0])+", ";
				}
				
			}
		}else {
			if(i<8 && board[i+1][j].charAt(0)!='W' && board[i+1][j].charAt(0)!='B') {
				PossibleMoves += (board[0][j].trim()+board[i+1][0])+", ";
			}
			if(i<8 && j>0 && board[i+1][j-1].charAt(0)!='B') {
				PossibleMoves += (board[0][j-1].trim()+board[i+1][0])+", ";
			}
			if(i<8 && j<8 && board[i+1][j+1].charAt(0)!='B') {
				PossibleMoves += (board[0][j+1].trim()+board[i+1][0])+", ";
			}
		}
		return PossibleMoves;
	}
	static String White_Pawn(String board[][],int i,int j,int k) {
		String PossibleMoves="";
		int a;
		if(k==0) {
			if(i==7) {
				for(a=i-1;a>4;a--) {
					PossibleMoves += (board[0][j].trim()+board[a][0])+", ";
				}
			}else {
				if(i>0 && board[i-1][j].charAt(0)!='W' && board[i-1][j].charAt(0)!='B') {
					PossibleMoves += (board[0][j].trim()+board[i-1][0])+", ";
				}
				if(i>0 && j>0 && board[i-1][j-1].charAt(0)=='B') {
					System.out.println("You can capture  : "+board[i-1][j-1]+" At Position : "+(board[0][j-1].trim()+board[i-1][0]));
					PossibleMoves += (board[0][j-1].trim()+board[i-1][0])+", ";
				}
				
				if(i>0 & j<8 && board[i-1][j+1].charAt(0)=='B') {
					System.out.println("You can capture  : "+board[i-1][j+1]+" At Position : "+(board[0][j+1].trim()+board[i-1][0]));
					PossibleMoves += (board[0][j+1].trim()+board[i-1][0])+", ";
				}
				
			}
		}else {//5 5
			if(i>0 && board[i-1][j].charAt(0)!='W' && board[i-1][j].charAt(0)!='B') {
				PossibleMoves += (board[0][j].trim()+board[i-1][0])+", ";
			}
			if(i>0 && j>0 && board[i-1][j-1].charAt(0)!='W') {
				PossibleMoves += (board[0][j-1].trim()+board[i-1][0])+", ";
			}
			if(i>0 & j<8 && board[i-1][j+1].charAt(0)!='W') {
				PossibleMoves += (board[0][j+1].trim()+board[i-1][0])+", ";
			}
		}
		return PossibleMoves;
	}
	
	//This Method is used to validate and print possible moves. Also Helps to make decision about the current move.
	static void PossibleMove(String board[][],String PossibleMoves,int i,int j) {
		String PositiontoMove,CurrentPosition;
		int m,n;
		Boolean Help;
		Scanner sc=new Scanner(System.in);
		if(PossibleMoves.equals("")) {
			System.out.println("No More Possible Move for This Coin...");
			CurrentCoin(board);
		}else {
			System.out.println("The Possible Moves Are : "+PossibleMoves);
			System.out.print("Enter The Position to Move : ");
			PositiontoMove=sc.next();
			System.out.println();
			PositiontoMove.trim();
			Help=CheckHelp(PossibleMoves,PositiontoMove);
			if(Help) {
				CurrentPosition=SelectedCoin(board,PositiontoMove);
				m=CurrentPosition.charAt(0)-48;
				n=CurrentPosition.charAt(2)-48;
				ChangeCoin(board,i,j,m,n,PositiontoMove);
			}else {
				System.out.println("Invalid Move... ");
				PossibleMove(board,PossibleMoves,i,j);
			}
			sc.close();
		}
	}
	
	// This Method is used to write the Coin moves to a Text File using basic IO...
	static void WriteFile(String s) {
		try {
			FileWriter fileWritter = new FileWriter(f1.getName(),true);
	        BufferedWriter bw = new BufferedWriter(fileWritter);
	        bw.write(s);
	        bw.close();
     } catch(IOException e){
        e.printStackTrace();
     }
	}
	
	//This Method Prints the player's Current Coin and get the possible moves of the particular coin
	static void PrintCurrentCoin(String board[][],int i,int j) {
		String PossibleMoves;
		if(board[i][j]=="B_R") {
			System.out.println("Selected Coin : Black_Rook");
			PossibleMoves=Black_Rook(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
		if(board[i][j]=="B_N") {
			System.out.println("Selected Coin : Black_Knight");
			PossibleMoves=Black_Knight(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
		if(board[i][j]=="B_B") {
			System.out.println("Selected Coin : Black_Bishop");
			PossibleMoves=Black_Bishop(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
		if(board[i][j]=="B_K") {
			System.out.println("Selected Coin : Black_King");
			PossibleMoves=Black_King(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
		if(board[i][j]=="B_Q") {
			System.out.println("Selected Coin : Black_Queen");
			PossibleMoves=Black_Queen(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
		if(board[i][j]=="B_P") {
			System.out.println("Selected Coin : Black_Pawn");
			PossibleMoves=Black_Pawn(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
		if(board[i][j]=="W_Q") {
			System.out.println("Selected Coin : White_Queen");
			PossibleMoves=White_Queen(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
		if(board[i][j]=="W_K") {
			System.out.println("Selected Coin : White_King");
			PossibleMoves=White_King(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
		if(board[i][j]=="W_R") {
			System.out.println("Selected Coin : White_Rook");
			PossibleMoves=White_Rook(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
		if(board[i][j]=="W_N") {
			System.out.println("Selected Coin : White_Knight");
			PossibleMoves=White_Knight(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
		if(board[i][j]=="W_B") {
			System.out.println("Selected Coin : White_Bishop");
			PossibleMoves=White_Bishop(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
		if(board[i][j]=="W_P") {
			System.out.println("Selected Coin : White_Pawn");
			PossibleMoves=White_Pawn(board,i,j,0);
			PossibleMove(board,PossibleMoves,i,j);
		}
	}

	//This Method is used to identify the position of the coin...
	static String SelectedCoin(String board[][],String coin_position) {
		int i,j;
		for(j=1;j<9;j++) {
			if(board[0][j].charAt(1) == coin_position.charAt(0)) {
				break;
			}
		}
		for(i=1;i<9;i++) {
			if(board[i][0].charAt(0) == coin_position.charAt(1)) {
				break;
			}
		}
		return i+" "+j;
		}
	
	//This Method is used to update the positions in the board based on the last move, Also Record the moves into a text file...
	static void ChangeCoin(String board[][],int i,int j,int m,int n,String PositiontoMove) {
		if(board[m][n]=="   ") {
			WriteFile("\ncoin "+board[i][j]+" Moved to "+PositiontoMove+System.lineSeparator());
			board[m][n]=board[i][j];
			board[i][j]="   ";
		}else {
			WriteFile("\ncoin "+board[m][n]+" Captured by the coin "+board[i][j]+" at the position "+PositiontoMove+System.lineSeparator());
			board[m][n]=board[i][j];
			board[i][j]="   ";
		}
		count++;
		CurrentCoin(board);
	}
	
	//This Method is used to print the current state of board
	static void print(String board[][]) {
		int i,j;System.out.println();
		for(i=0;i<9;i++) {
			for(j=0;j<9;j++) {
				System.out.print(board[i][j]+"  ");
			}
			System.out.println();
		}
		System.out.println();
	}

	
	static void Print_Help(String board[][],boolean Not_Safe, int i,int j) {
		if(Not_Safe) {
			System.out.println("The coin "+board[i][j]+" in Position "+(board[0][j].trim()+board[i][0])+" can capture your coin if you move to that position");
			CurrentCoin(board);
		}
	}
	
	//This Method is used to help the player to identify the Obstacle or Dangerous Position based on the given coin position(Eg: d5 --help)...
	static void Help(String coin_position,String board[][]) {
		String Help="";
		Boolean Not_Safe=false;
		int i,j;
		String Help_Position=coin_position.charAt(0)+(coin_position.charAt(1)+" ").trim();
		Help_Position.trim();
		if(count%2==0) {
			for(i=1;i<9;i++) {
				for(j=1;j<9;j++) {
					if(board[i][j]=="B_P") {
						Help=Black_Pawn(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					if(board[i][j]=="B_R") {
						Help=Black_Rook(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					if(board[i][j]=="B_N") {
						Help=Black_Knight(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					if(board[i][j]=="B_B") {
						Help=Black_Bishop(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					
					if(board[i][j]=="B_K") {
						Help=Black_King(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					if(board[i][j]=="B_Q") {
						Help=Black_Queen(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					
				}
			}
			if(!Not_Safe) {
				System.out.println("Safe Place");
				CurrentCoin(board);
			}
		}
		if(count%2!=0) {
			for(i=1;i<9;i++) {
				for(j=1;j<9;j++) {
					if(board[i][j]=="W_P") {
						Help=White_Pawn(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					if(board[i][j]=="W_R") {
						Help=White_Rook(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					if(board[i][j]=="W_N") {
						Help=White_Knight(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					if(board[i][j]=="W_B") {
						Help=White_Bishop(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					if(board[i][j]=="W_K") {
						Help=White_King(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					if(board[i][j]=="W_Q") {
						Help=White_Queen(board,i,j,1);
						Not_Safe=CheckHelp(Help,Help_Position);
						Print_Help(board,Not_Safe,i,j);
					}
					
				}
			}
			if(!Not_Safe) {
				System.out.println("Safe Place");
				CurrentCoin(board);
				
			}
		}
	}
	
	//This method is acting as a Helper method for Help() to identify the Obstacle based on the calculated possible moves...
	static Boolean CheckHelp(String Help,String Help_Position) {
		String s="";
		int i,len;
		len=Help.length();
		for(i=0;i<len;i++) {
			if(Help.charAt(i)>=97 && Help.charAt(i)<=104) {
				s=Help.charAt(i)+(Help.charAt(i+1)+" ").trim();
				if(Help_Position.equals(s)) {
					return true;
				}
			}
		}
		 return false;
	}
	
	//This Method instructs the player to interact with the on-going game...
	static void CurrentCoin(String board[][]) {
		Scanner sc=new Scanner(System.in);
		int i,j,exit=0;
		String coin_position,CurrentPosition;
			if(count%2==0) {
				System.out.print("White's Turn : ");
			}else {
				System.out.print("Black's Turn : ");
			}
			coin_position=sc.nextLine();
			System.out.println();
			
			
			if(coin_position.equals("exit") || coin_position.equals("Exit")) {
				exit=1;
			}
			if(coin_position.equals("Print") || coin_position.equals("print")) {
				print(board);
				CurrentCoin(board);
			}
			if(coin_position.length()>5) {
				Help(coin_position,board);
				CurrentCoin(board);
			}
			if(exit==0) {
				CurrentPosition=SelectedCoin(board,coin_position);
				i=CurrentPosition.charAt(0)-48;
				j=CurrentPosition.charAt(2)-48;
				if(board[i][j]=="   ") {
					System.out.println("Pick a Valid Coin");
					CurrentCoin(board);
				}
				if(count%2==0 && board[i][j].charAt(0)=='B') {
					System.out.println("You Cannot Pick Opponent Coin ");
					CurrentCoin(board);
				}
				if(count%2!=0 && board[i][j].charAt(0)=='W') {
					System.out.println("You Cannot Pick Opponent Coin ");
					CurrentCoin(board);
				}
				PrintCurrentCoin(board,i,j);
			}
		sc.close();
	}

	//This method is used to prepare the board for the First Time...
	static void Board() {
		
		int i,j;
		String board[][]=new String[9][9];
		board[0][0]=" ";
		for(i=1;i<9;i++) {
			board[0][i]=" "+(char)('a'-1+i)+" ";
		}
		for(i=1;i<9;i++) {
			board[i][0]=(8+1-i)+"";
		}
		for(i=2;i<9;i+=5) {
			for(j=1;j<9;j++) {
				if(i==2) {
					board[i][j]="B_P";
				}else {
					board[i][j]="W_P";
				}
			}
		}
		board[1][1]="B_R";board[1][2]="B_N";board[1][3]="B_B";board[1][4]="B_Q";
		board[1][5]="B_K";board[1][6]="B_B";board[1][7]="B_N";board[1][8]="B_R";
		board[8][1]="W_R";board[8][2]="W_N";board[8][3]="W_B";board[8][4]="W_Q";
		board[8][5]="W_K";board[8][6]="W_B";board[8][7]="W_N";board[8][8]="W_R";
		for(i=1;i<9;i++) {
			for(j=0;j<9;j++) {
				if(board[i][j]==null) {
					board[i][j]="   ";
				}
			}
		}
		CurrentCoin(board);
	}

	public static void main(String[] args) {
		System.out.println("You Have The Choices to EXIT, PRINT OR HELP...");
		System.out.println("1. exit -> get out of the game...");
		System.out.println("2. Print -> show the current state of the board...");
		System.out.println("3. <Position> --help (d5 --help)-> Check if the coin can be captured, if moved to that particular position...");
		System.out.println();
		 try { 
	         String FileName = "Game Log "+java.time.LocalDate.now()+" "+(new Date()).getTime()+".txt";
	         
	         f1 = new File(System.getProperty("user.dir")+"\\"+FileName);
	         if(!f1.exists()) {
	            f1.createNewFile();
	         } 
		 }catch(IOException e){
			 System.out.println("Error when creating file");
	             e.printStackTrace();
	         }
		Board();
	}
}
