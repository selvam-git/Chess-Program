Things to Note
-----------------------------------------------------------
1. The Game play is interactive enough to guide the Player.
2. The Solution Covers the problem statement given.
3. Every new game play will create a new GameLog file every time in the current directory.

Deployment Steps
-----------------------------------------------------------
1. Compile Chess.java file.
2. Excute the program